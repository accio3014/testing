from flask import Blueprint, url_for, render_template, request, jsonify
from werkzeug.utils import redirect

from carspecspage.models import Manufacture, CarList, CarListDetail

from flask import jsonify

bp = Blueprint('index', __name__, url_prefix='/')


@bp.route('/')
def index():
    manufactures = Manufacture.query.all()
    car_list = CarList.query.all()
    car_list_detail = CarList.query.all()
    return render_template('parking_size.html', manufactures=manufactures, car_list=car_list, car_list_detail=car_list_detail)


@bp.route('/get_models/<manufacturer>', methods=['GET'])
def get_models(manufacturer):
    models = CarList.query.filter_by(manufacture=manufacturer).all()
    model_names = [{'modelName': model.modelName} for model in models]
    return jsonify(model_names)


@bp.route('/get_models_detail/<carModel>', methods=['GET'])
def get_models_detail(carModel):
    model_name = CarListDetail.query.filter_by(modelName=carModel).all()
    detail_model_names = [{'modelName': model.detailModelName} for model in model_name]
    return jsonify(detail_model_names)


@bp.route('/get_car_detail/<detail_model>', methods=['GET'])
def get_car_detail(detail_model):
    car_detail = CarListDetail.query.filter_by(detailModelName=detail_model).first()
    if car_detail:
        print(car_detail.length)
        return jsonify({
            'length': car_detail.length,
            'width': car_detail.width,
            'height': car_detail.height
        })
    return jsonify({'error': 'Not found'})