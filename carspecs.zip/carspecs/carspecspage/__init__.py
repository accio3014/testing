from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

import config

db = SQLAlchemy()
migrate = Migrate()


def create_app():
    app = Flask(__name__)
    app.config.from_object(config)

    # ORM, DB setting
    db.init_app(app)
    migrate.init_app(app, db)
    from . import models

    from .views import index_view
    app.register_blueprint(index_view.bp)   # main_views.py에 있는 bp Object를 사용


    return app