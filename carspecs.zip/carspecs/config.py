import os

BASE_DIR = os.path.dirname(__file__)

SQLALCHEMY_DATABASE_URI = 'sqlite:///{}'.format(os.path.join(BASE_DIR, 'carList.db?charset=utf8mb4'))
SQLALCHEMY_TRACK_MODIFICATIONS = False